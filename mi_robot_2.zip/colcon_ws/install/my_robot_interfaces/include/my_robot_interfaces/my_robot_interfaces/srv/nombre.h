// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_robot_interfaces:srv/Nombre.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACES__SRV__NOMBRE_H_
#define MY_ROBOT_INTERFACES__SRV__NOMBRE_H_

#include "my_robot_interfaces/srv/detail/nombre__struct.h"
#include "my_robot_interfaces/srv/detail/nombre__functions.h"
#include "my_robot_interfaces/srv/detail/nombre__type_support.h"

#endif  // MY_ROBOT_INTERFACES__SRV__NOMBRE_H_
