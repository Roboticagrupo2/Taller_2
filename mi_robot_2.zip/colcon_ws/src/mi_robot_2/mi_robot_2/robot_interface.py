#!/usr/bin/env python3

#----------------------------------------------#
#NODO TURTLE_BOT_INTERFACE
#Interfaz General del Control del Robot
#Taller #1 ROBÓTICA
#----------------------------------------------#

#LIBRERÍAS
import sys
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
from tkinter import filedialog
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from matplotlib.patches import Rectangle
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import subprocess
import time
from my_robot_interfaces.srv import Nombre
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog
import threading
from matplotlib.figure import Figure

#CLASES PARA LA CREACIÓN DE LAS DISTINTAS PANTALLAS DE LA INTERFAZ
#----------------------------------------------#

#Pantalla Principal
class MiApp(QMainWindow):
   def __init__(self):
       super(MiApp, self).__init__()
       loadUi("/home/edwardman/colcon_ws/src/mi_robot_2/mi_robot_2/intpri.ui", self)

       #Detección de los botones para el cambio de pantalla 
       self.pushButton_2.clicked.connect(self.gotoOperar)
       self.pushButton.clicked.connect(self.gotoPlayer)

   def gotoOperar(self):
        widget.setCurrentIndex(widget.currentIndex() + 1)
        t3.run()
    
   def gotoPlayer(self):
        t4.run()
        self.load_trajectory()
        widget.setCurrentIndex(widget.currentIndex() + 2)
    
   #Cargar la trayectoria para el punto 4 
   def load_trajectory(self):
        self.file_name = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.file_name:
            #Crear el servicio del punto 4
            self.srv = robot_interface.create_service(Nombre,'txt_name', self.send_txt_name)
            pass
     
   def send_txt_name(self, request, response):
        response.name = self.file_name
        return response


#Pantalla de operación
class Operar(QMainWindow):
    def __init__(self):
        super(Operar, self).__init__()
        loadUi("/home/edwardman/colcon_ws/src/mi_robot_2/mi_robot_2/intop.ui", self)

        #Creación de la grafica de la posición del robot
        self.canvas = MakeGraph(self, dpi=100)
        self.ponerlagraficaaqui.addWidget(self.canvas)

        #Coordenadas de la posición
        self.register_x = pos_x
        self.register_y = pos_y

        self.update_plot()

        #Detección de botones para guardar imagen y trayectoria
        self.save_graph.clicked.connect(self.save_img)
        self.save_record.clicked.connect(self.save_trajectory)

        #Timer para la actualización constante de la gráfica
        self.timer = QtCore.QTimer()
        self.timer.setInterval(10)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start()
        
    #FUnción para graficar la posición del robot en la gráfica
    def update_plot(self):

        self.title = self.graph_name.text()

        self.canvas.ax.cla()  
        self.canvas.ax.plot(self.register_x, self.register_y, color="black")  
        
        x_start, x_end = -500, 500
        y_start, y_end = -500, 500
    
      
        if self.register_x and self.register_y:
            #x_start, x_end = -300+self.register_x[-1], 300+self.register_x[-1]
            #y_start, y_end = -300+ self.register_y[-1], 300 + self.register_y[-1]
            self.canvas.ax.plot(self.register_x[-1], self.register_y[-1], marker="o", markersize=25, color="red")
            self.canvas.ax.plot(self.register_x[-1], self.register_y[-1], marker="o", markersize=20, color="white")

        self.canvas.ax.grid(True, which='both', linestyle='--', linewidth=0.5)  
        self.canvas.ax.set_xlim([x_start, x_end])
        self.canvas.ax.set_ylim([y_start, y_end])
        self.canvas.ax.set_title(self.title)
        self.canvas.draw()
    
    #Función para guardar la gráfica
    def save_img(self):
        self.filename_graph = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("All Files", "*.*")])
        if(self.filename_graph):
            info = np.array(self.canvas.renderer.buffer_rgba())
            plt.imsave(self.filename_graph, info)
    
    #Función para guardar la trayectoria
    def save_trajectory(self):
        self.filename_tray = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        file = open(self.filename_tray, "w")
        for i in velocities:
            file.write(i)
        file.close()

#Ventana para la reproducción de movimiento (Punto 4)
class Player(QMainWindow):
    def __init__(self):
        super(Player, self).__init__()
        loadUi("/home/edwardman/colcon_ws/src/mi_robot_2/mi_robot_2/intpla.ui", self)
        self.canvas = MakeGraph(self, dpi=100)
        self.ponerlagraficaaqui.addWidget(self.canvas)

        self.register_x = pos_x
        self.register_y = pos_y

        self.update_plot()

        self.save_graph.clicked.connect(self.save_img)

        self.timer = QtCore.QTimer()
        self.timer.setInterval(10)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start()
        

    def update_plot(self):

        self.title = self.graph_name.text()

        self.canvas.ax.cla()  
        self.canvas.ax.plot(self.register_x, self.register_y, color="black")  
        
        x_start, x_end = -500, 500 
        y_start, y_end = -500, 500  
    
      
        if self.register_x and self.register_y:
            self.canvas.ax.plot(self.register_x[-1], self.register_y[-1], marker="o", markersize=25, color="red")
            self.canvas.ax.plot(self.register_x[-1], self.register_y[-1], marker="o", markersize=20, color="white")
            
        self.canvas.ax.grid(True, which='both', linestyle='--', linewidth=0.5)  
        self.canvas.ax.set_xlim([x_start, x_end])
        self.canvas.ax.set_ylim([y_start, y_end])
        self.canvas.ax.set_title(self.title)
        self.canvas.draw()
    
    def save_img(self):
        self.filename_graph = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("All Files", "*.*")])
        if(self.filename_graph):
            info = np.array(self.canvas.renderer.buffer_rgba())
            plt.imsave(self.filename_graph, info)

#----------------------------------------------#

#NODO DE LA INTERFAZ
            
#----------------------------------------------#

class RobotInterface(Node):

    def __init__(self):
        super().__init__("robot_interface")

        #Variables para guardar la posición en X e Y.
        self.register_x = []
        self.register_y = []

        #Guardar el tiempo
        self.timer=time.time()

        #Subscribers del nodo
        self.twist_subscriber = self.create_subscription(Twist, "/robot_position", self.read_position, 10)
        self.velocities_subscriber = self.create_subscription(Twist, "/robot_cmdVel", self.read_velocity, 10)
        
        #Variable global para guardar las velocidades
        global velocities
        velocities = []

    #Función para leer la posición mediante el nodo
    def read_position(self, msg):
        self.register_x.append(msg.linear.x)
        pos_x.append(msg.linear.x)
        self.register_y.append(msg.linear.y)
        pos_y.append(msg.linear.y)


    #Función para leer la velocidad mediante el nodo
    def read_velocity(self, msg):
            velocities.append("Velocity: [{},{}, {}, {}]\n".format(time.time(),msg.linear.x,msg.linear.y, msg.angular.z))

#----------------------------------------------#
            

#CLASE PARA CREAR LA GRÁFICA DE LOS PUNTOS 2 Y 4

class MakeGraph(FigureCanvas):
    def __init__(self, parent=None, dpi=200):
        fig = Figure(dpi=dpi)
        self.ax = fig.add_subplot(1, 1, 1)
        super(MakeGraph, self).__init__(fig)

#FUNCIÓN PARA EJECUTAR LA APLICACIÓN

def execute_app():
    app = QApplication(sys.argv)
    global widget
    widget = QtWidgets.QStackedWidget()
    mainwindow = MiApp()
    operarwindow = Operar()
    playerwindow = Player()
    widget.addWidget(mainwindow)
    widget.addWidget(operarwindow)
    widget.addWidget(playerwindow)

    widget.setFixedWidth(700)
    widget.setFixedHeight(500)
    widget.show()
    sys.exit(app.exec_())

#FUNCIÓN PARA EJECUTAR EL NODO DE LA INTERFAZ

def execute_node(args=None):
    rclpy.init(args=args)
    global robot_interface
    robot_interface = RobotInterface()
    rclpy.spin(robot_interface)
    if hasattr(robot_interface, 'f'):
        robot_interface.f.close()
    rclpy.shutdown()

#FUNCIÓN PARA EJECUTAR EL NODO TURTLE_BOT_TELEOP

def run_teleop():
    subprocess.run("pwd")
    subprocess.Popen(["ros2 run mi_robot_2 robot_teleop"], shell=True)

#FUNCIÓN PARA EJECUTAR EL NODO TURTE_BOT_PLAYER

def run_player():
    subprocess.Popen(["ros2 run mi_robot_2 robot_player"], shell=True)

#FUNCIÓN MAIN

def main(args=None):

    #Variables globales para la posición en X e Y.
    global pos_x
    pos_x = []
    global pos_y
    pos_y = []

    #Thread para la ejecución del nodo
    t1 = threading.Thread(target=execute_node)

    #Thread para la ejecución del nodo teleop
    global t3
    t3 = threading.Thread(target =run_teleop)

    #Inicio del thread del nodo 
    t1.start()

    #Thread para la ejecución del nodo player
    global t4
    t4 = threading.Thread(target = run_player)

    #Llamada a la función del inicio de la app
    execute_app()

if __name__ == '__main__':
    main()


